<?php 
	require('./config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<script>
					$(function(){
						var path = window.parent.ADMIN_PATH;
						if (!path) {
							$("#cmstips").css("display","block");
						}
					});
				</script>
				<blockquote class="layui-elem-quote layui-texts" id="cmstips" style="display:none;margin-bottom:30px;">
					<?php if($config['binding']){ ?>欢迎回来，<?php echo $config['binding']['buy_username'] ?>， <?php } ?>当前访问模式不支持图片上传功能，如需上传图片请通过CMS后台菜单入口访问主题后台！
				</blockquote>
				<fieldset class="layui-elem-field">
					<legend>主题介绍</legend>
					<div class="layui-field-box">
						<div class="layui-row">
							<div class="layui-col-md4">
								<table class="layui-table">	
									<tbody>
										<tr>
											<td class="layui-font-gray">主题名称</td>
											<td><?php echo $info['name'];?></td>
										</tr>
										<tr>
											<td class="layui-font-gray">当前版本</td>
											<td><?php echo $info['version'];?></td>
										</tr> 
										<tr>
											<td class="layui-font-gray">更新日期</td>
											<td><?php echo $info['inputtime'];?></td>
										</tr>
									</tbody>
								</table> 
							</div>
							<div class="layui-col-md4" style="padding: 0 15px;">
								<table class="layui-table">	
									<tbody>
										<tr>
											<td class="layui-font-gray">发布时间</td>
											<td><?php echo $info['updatetime'];?></td>
										</tr>	
										<tr>
											<td class="layui-font-gray">主题作者</td>
											<td><?php echo $info['author'];?></td>
										</tr>		        	
										<tr>
											<td class="layui-font-gray">联系作者</td>
											<td><?php echo $info['qq'];?></td>
										</tr>
									</tbody>
								</table>   
							</div>
							<div class="layui-col-md4">
								<table class="layui-table">	
									<tbody>
										<tr>
											<td class="layui-font-gray">适用版本</td>
											<td><?php echo $info['system'];?></td>
										</tr>
										<tr>
											<td class="layui-font-gray">兼容浏览器</td>
											<td>IE10+ Chrome25+</td>
										</tr>
										<tr>
											<td class="layui-font-gray">官网地址</td>
											<td> <a target="_blank" href="<?php echo $info['website'];?>"><?php echo $info['website'];?></a></td>
										</tr>
										
									</tbody>
								</table>
							</div>
							<div class="layui-font-red" style="text-align: center">
								原创作品，请勿转发、倒卖、破解等，一经发现取消授权资格以及售后服务，严重者封禁账号！！！
							</div>
						</div>
					</div>
				</fieldset>
				
				<fieldset class="layui-elem-field" style="margin-top: 30px;">
					<legend>常用设置</legend>
					<div class="layui-field-box">
						
						<form class="layui-form" method="post" action="?url=index&array=set&type=post" enctype="multipart/form-data">
							<?php config_input('index',$config['set']) ?>
							<div class="layui-form-item">
								<div class="layui-input-block">
									<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
									<button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="?url=index&array=set&type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！">
										<i class="layui-icon layui-icon-delete"></i> 清空设置
									</button>
									<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
								</div>
							</div>
						</form>
					</div>
				</fieldset>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

