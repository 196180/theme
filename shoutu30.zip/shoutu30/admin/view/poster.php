<?php
	require('./config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<blockquote class="layui-elem-quote layui-text">
  					当前设置对站点全局有效，下拉框没有的参数可手动填写要调用的标签，具体可参考<a href="#" target="_blank">官方文档</a>。
				</blockquote>
				<fieldset class="layui-elem-field">
					<legend>竖版海报设置</legend>
					<div class="layui-field-box">
						<form class="layui-form" method="post" action="?url=poster&array=poster&type=post" enctype="multipart/form-data">
							<div class="layui-form-item">
								<label class="layui-form-label">懒加载背景图</label>
								<div class="layui-input-inline w420">
									<input type="text" class="layui-input upload-input" value="<?php echo $config['poster']['lopimg'];?>" name="lopimg">
									<?php if($config['poster']['lopimg']){ ?>
									<div class="layui-form-mid layui-word-aux">
										<img style="max-width: 220px;" src="<?php echo $config['poster']['lopimg'];?>" />
									</div>
									<?php }?>
								</div>
								<div class="layui-input-inline ">
									<button type="button" class="layui-btn layui-upload">上传图片</button>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">高度比例</label>
								<div class="layui-input-inline" style="width: 280px;">
									<input name="high" type="hidden" value="<?php echo $config['poster']['high'];?>">
									<div class="slider" data-min="20" data-max="200"></div>
								</div>
								<div class="layui-form-mid layui-word-aux">%</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">副标题</label>
								<div class="layui-input-inline" style="width: 120px;">
									<select lay-filter="filter">
										<?php echo config_option('title',$config['poster']['subtitle']); ?>
									</select>
								</div>
								<div class="layui-input-inline" style="width: 120px;">
									<input name="subtitle" type="text" value="<?php echo $config['poster']['subtitle'];?>" placeholder="自定义" size="60" class="layui-input value">
								</div>
								<div class="layui-input-inline">
									<input type="hidden" name="subtitle_is" value="0">
									<input type="checkbox" lay-skin="primary" name="subtitle_is" value="1" title="显示" <?php if($config['poster']['subtitle_is']) { echo "checked"; }?>>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">附加数据</label>
								<div class="layui-input-inline" style="width: 260px; margin-right: 0;">
									<div class="layui-input-inline" style="width: 120px;">
										<select lay-filter="filter">
											<?php echo config_option('title',$config['poster']['text']); ?>
										</select>
									</div>
									<div class="layui-input-inline" style="width: 120px;">
										<input name="text" type="text" value="<?php echo $config['poster']['text'];?>" placeholder="自定义" size="60" class="layui-input value">
									</div>
								</div>
								<div class="layui-input-inline" style="width: 130px;">
									<div class="layui-input-inline" style="width: 120px;">
										<select lay-filter="filter">
											<option value="center"<?php if($config['poster']['position']=='center') { echo "selected"; }?>>居中</option>
											<option value="left"<?php if($config['poster']['position']=='left') { echo "selected"; }?>>向左</option>
											<option value="right"<?php if($config['poster']['position']=='right') { echo "selected"; }?>>向右</option>
										</select>
									</div>
									<div class="layui-input-inline" style="width: 120px;">
										<input name="position" type="hidden" value="<?php echo $config['poster']['position'];?>" size="60" class="layui-input value">
									</div>
								</div>
								<div class="layui-input-inline">
									<input type="hidden" name="text_is" value="0">
									<input type="checkbox" lay-skin="primary" name="text_is" value="1" title="显示" <?php if($config['poster']['text_is']) { echo "checked"; }?>>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">圆角</label>
								<div class="layui-input-inline" style="width: 280px;">
									<input name="radius" type="hidden" value="<?php echo $config['poster']['radius'];?>">
									<div class="slider" data-min="2" data-max="20"></div>
								</div>
								<div class="layui-form-mid layui-word-aux">px</div>
							</div>							
							<div class="layui-form-item">
								<div class="layui-input-block">
									<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
									<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
								</div>
							</div>
						</form>
					</div>
				</fieldset>
				
				<fieldset class="layui-elem-field" style="margin-top: 30px;">
					<legend>横版海报设置</legend>
					<div class="layui-field-box">
						<form class="layui-form" method="post" action="?url=poster&array=poster2&type=post" enctype="multipart/form-data">
							<div class="layui-form-item">
								<label class="layui-form-label">懒加载背景图</label>
								<div class="layui-input-inline w420">
									<input type="text" class="layui-input upload-input" value="<?php echo $config['poster2']['lopimg'];?>" name="lopimg">
									<?php if($config['poster2']['lopimg']){ ?>
									<div class="layui-form-mid layui-word-aux">
										<img style="max-width: 220px;" src="<?php echo $config['poster2']['lopimg'];?>" />
									</div>
									<?php }?>
								</div>
								<div class="layui-input-inline ">
									<button type="button" class="layui-btn layui-upload">上传图片</button>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">高度比例</label>
								<div class="layui-input-inline" style="width: 280px;">
									<input name="high" type="hidden" value="<?php echo $config['poster2']['high'];?>">
									<div class="slider" data-min="20" data-max="200"></div>
								</div>
								<div class="layui-form-mid layui-word-aux">%</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">副标题</label>
								<div class="layui-input-inline" style="width: 120px;">
									<select lay-filter="filter">
										<?php echo config_option('title',$config['poster2']['subtitle']); ?>
									</select>
								</div>
								<div class="layui-input-inline" style="width: 120px;">
									<input name="subtitle" type="text" value="<?php echo $config['poster2']['subtitle'];?>" placeholder="自定义" size="60" class="layui-input value">
								</div>
								<div class="layui-input-inline">
									<input type="hidden" name="subtitle_is" value="0">
									<input type="checkbox" lay-skin="primary" name="subtitle_is" value="1" title="显示" <?php if($config['poster2']['subtitle_is']) { echo "checked"; }?>>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">附加数据</label>
								<div class="layui-input-inline" style="width: 260px; margin-right: 0;">
									<div class="layui-input-inline" style="width: 120px;">
										<select lay-filter="filter">
											<?php echo config_option('title',$config['poster2']['text']); ?>
										</select>
									</div>
									<div class="layui-input-inline" style="width: 120px;">
										<input name="text" type="text" value="<?php echo $config['poster2']['text'];?>" placeholder="自定义" size="60" class="layui-input value">
									</div>
								</div>
								<div class="layui-input-inline" style="width: 130px;">
									<div class="layui-input-inline" style="width: 120px;">
										<select lay-filter="filter">
											<option value="center"<?php if($config['poster2']['position']=='center') { echo "selected"; }?>>居中</option>
											<option value="left"<?php if($config['poster2']['position']=='left') { echo "selected"; }?>>向左</option>
											<option value="right"<?php if($config['poster2']['position']=='right') { echo "selected"; }?>>向右</option>
										</select>
									</div>
									<div class="layui-input-inline" style="width: 120px;">
										<input name="position" type="hidden" value="<?php echo $config['poster2']['position'];?>" size="60" class="layui-input value">
									</div>
								</div>
								<div class="layui-input-inline">
									<input type="hidden" name="text_is" value="0">
									<input type="checkbox" lay-skin="primary" name="text_is" value="1" title="显示" <?php if($config['poster2']['text_is']) { echo "checked"; }?>>
								</div>
							</div>
							<div class="layui-form-item">
								<div class="layui-input-block">
									<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
									<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
								</div>
							</div>
						</form>
					</div>
				</fieldset>
				<fieldset class="layui-elem-field" style="margin-top: 30px;">
					<legend>文字列表设置</legend>
					<div class="layui-field-box">
						<form class="layui-form" method="post" action="?url=poster&array=textlist&type=post" enctype="multipart/form-data">
							<div class="layui-form-item">
								<label class="layui-form-label">副标题</label>
								<div class="layui-input-inline" style="width: 120px;">
									<select lay-filter="filter">
										<?php echo config_option('title',$config['textlist']['subtitle']); ?>
									</select>
								</div>
								<div class="layui-input-inline" style="width: 120px;">
									<input name="subtitle" type="text" value="<?php echo $config['textlist']['subtitle'];?>" placeholder="自定义" size="60" class="layui-input value">
								</div>
							</div>
							<div class="layui-form-item">
								<div class="layui-input-block">
									<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
									<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
								</div>
							</div>
						</form>
					</div>
				</fieldset>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

