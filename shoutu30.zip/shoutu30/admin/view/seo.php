<?php
	require('./config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<blockquote class="layui-elem-quote layui-text">
  					你可以插入常有标签也可以手动插入标签，写法：[vod_xxx]，具体标签可通过官方文档获取，<a href="https://www.taozhuti.cn/code/11.html" target="_blank">查看官方标签</a>。
				</blockquote>
				<?php
					$array = require('./input.php');
					foreach ($array['aid'] as $title => $val) {
				?>
				<fieldset class="layui-elem-field" style="margin-top: 30px;">
					<legend><?php echo $title; ?></legend>
					<div class="layui-field-box">
						<form class="layui-form" method="post" action="?url=seo&array=seo<?php echo $val; ?>&type=post" enctype="multipart/form-data">
							<div class="layui-form-item">
								<div class="layui-input-inline" style="width: 800px;">
									<input name="title" placeholder="标题" class="layui-input" value="<?php echo $config['seo'.$val]['title']; ?>" required lay-verify="required"/>
									<div class="layui-form-mid layui-word-aux" style="margin-bottom:10px;">插入常用标签：<a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[site_name]">[网站标题]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[vod_name]">[视频名称]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[type_name]">[分类名称]</a>  <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[topic_name]">[专题名称]</a></div>
								</div>
								<div class="layui-input-inline" style="width: 390px;">
									<textarea name="key" rows="5" placeholder="关键词" class="layui-textarea"><?php echo $config['seo'.$val]['key']; ?></textarea>
									<div class="layui-form-mid layui-word-aux">插入常用标签：<a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[site_keywords]">[网站关键词]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[vod_class]">[视频剧情]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[vod_actor]">[视频主演]</a></div>
								</div>
								<div class="layui-input-inline" style="width: 400px;">
									<textarea name="des" rows="5" placeholder="描述" class="layui-textarea"><?php echo $config['seo'.$val]['des']; ?></textarea>
									<div class="layui-form-mid layui-word-aux">插入常用标签：<a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[site_description]">[网站描述]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[vod_blurb]">[视频简介]</a> <a class="layui-btn layui-btn-xs layui-addval" href="javascript:;" data-val="[topic_blurb]">[专题简介]</a></div>
								</div>
							</div>
							<div class="layui-form-item">
								<label class="layui-form-label">启用自定义文件</label>
								<div class="layui-input-inline" style="width: auto;">
									<input type="hidden" name="diy" value="">
									<input type="checkbox" lay-skin="switch" name="diy" value="1"<?php if($config['seo'.$val]['diy']) { echo "checked"; }?>>
								</div>
								<div class="layui-form-mid layui-word-aux">开启后请通过模板文件修改SEO参数，目录位置：根目录/template/模板/html/seo/</div>
							</div>
							<div class="layui-form-item" style="padding-top: 20px; text-align: center;">
								<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button><a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
							</div>
						</form>
					</div>
				</fieldset>
				<?php } ?>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

