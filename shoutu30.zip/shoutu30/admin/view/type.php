<?php 
	require('./config.php');
	$data = $config['type'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php');?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<blockquote class="layui-elem-quote layui-text">
  					模块组逻辑：填写标题》选择模块》填写模块参数，模块参数是指分类id或对应模块的值等，例如广告模块填广告id，其他选项可根据需求选择，获取当前分类、主演等参数值填写current，全部分类填写all，具体可查看<a href="#" target="_blank">官方教程</a>操作。
				</blockquote>
				<fieldset class="layui-elem-field">
					<legend>指定分类为栏目</legend>
					<div class="layui-field-box">
						<form class="layui-form" method="post" action="?url=type&array=typeid&type=add" enctype="multipart/form-data">
							<div class="layui-form-item">					
								<div class="layui-input-inline" style="width: 120px;">
									<input type="text" name="title" placeholder="标题" class="layui-input" value="">
								</div>
								<div class="layui-input-inline" style="width: 120px;">
									<input type="text" name="id" placeholder="分类id" class="layui-input" value="">
								</div>
								<div class="layui-input-inline" style="width: auto;">
									<button type="submit" class="layui-btn layui-btn-warm"><i class="layui-icon layui-icon-addition"></i> 添加一组</button>
								</div>
								<div class="layui-form-mid layui-word-aux">指定某分类为栏目，支持二级分类，可对栏目单独设置独立的模块组</div>
							</div>
						</form>
					</div>
				</fieldset>
				<div class="layui-tab" style="margin-top: 30px;">
					<ul class="layui-tab-title">
						<?php
							if(is_array($config['typeid']['data'])){
							foreach ($config['typeid']['data'] as $key => $value) {
						?>
						<li class="<?php if($key=='0'){ ?>layui-this<?php } ?>"><?php echo $value['title']; ?>
							<i class="layui-icon layui-icon-close layui-unselect layui-tab-close" data-key="<?php echo $key; ?>" data-id="<?php echo $value['id']; ?>"></i>
						</li>
						<?php }} ?>
					</ul>
					<div class="layui-tab-content" style="padding: 0;margin-top: 20px;">
						<?php
							if(is_array($config['typeid']['data'])){
							foreach ($config['typeid']['data'] as $key2 => $value2) {
							$href = '?url=type&array=type'.$value2['id'].'&';
						?>
						<div class="layui-tab-item<?php if($key2=='0'){ ?> layui-show<?php } ?>">
							<div class="swiper">
								<div class="swiper-wrapper">
									<?php config_block_post('type'.$value2['id'],$href);?>
								</div>
								<div style="margin-top: 20px; text-align: center;">
									<a href="javascript:;" class="layui-btn layui-btn-sm layui-btn-normal left-prev">上一个</a>
									<span class="layui-btn layui-btn-sm layui-btn-primary lef-page" style="width: auto;"></span>
									<a href="javascript:;" class="layui-btn layui-btn-sm layui-btn-normal right-next">下一个</a>
								</div>
								<div class="swiper-pagination"></div>
								<div class="swiper-button-prev"></div>
								<div class="swiper-button-next"></div>
							</div>
							<form class="layui-form" method="post" action="?url=type&array=type<?php echo $value2['id']; ?>&type=post" enctype="multipart/form-data">
								<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
									<legend>已添加的模块组 - 支持拖拽排序哦！</legend>
								</fieldset>
								<?php
									if(is_array($config['type'.$value2['id']]['data'])){
										config_block('type'.$value2['id'],$config['type'.$value2['id']]['data'],$href);
									}
								?>
								<div class="layui-form-item" style="padding-top: 20px; text-align: center;">
									<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button><button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="<?php echo $href;?>type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！"><i class="layui-icon layui-icon-delete"></i> 清空模块</button><a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
								</div>
							</form>
						</div>
						<?php }} ?>
					</div>
				</div>
			</div>
		</div>
		<script>
			$('.layui-tab-close').on('click', function(){
				let id = $(this).attr('data-id');
				let key = $(this).attr('data-key');
				let url = '?url=type&array=type'+id+'&type=empty&id='+key;
				layer.confirm('操作删除后栏目下所以模块也将被清空<br>您确定要删除栏目吗？,该操作不可撤销！', {
					btn: ['确认','取消'],
				}, function(){
					location.href=url;
				}, function(){
					layer.closeAll('confirm');
				});
			});
		</script>
		<?php require('footer.php'); ?>
	</body>
</html>

