<?php
	require('./config.php');
	$data = $config['other'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<form class="layui-form" method="post" action="?url=more&array=other&type=post" enctype="multipart/form-data">
					<div class="layui-form-item">
						<label class="layui-form-label">夜间模式</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="cloredark" value="">
							<input type="checkbox" lay-skin="switch" name="cloredark" value="dark"<?php if($data['cloredark']) { echo "checked"; }?>>
						</div>
						<div class="layui-form-mid layui-word-aux">开启后进站默认夜间模式，不影响前端用户切换</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">分类筛选模块</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="type" value="0">
							<input type="checkbox" lay-skin="primary" name="type" value="1" title="分类" <?php if($data['type']) { echo "checked"; }?>>
							<input type="hidden" name="class" value="0">
							<input type="checkbox" lay-skin="primary" name="class" value="1" title="剧情" <?php if($data['class']) { echo "checked"; }?>>
							<input type="hidden" name="area" value="0">
							<input type="checkbox" lay-skin="primary" name="area" value="1" title="地区" <?php if($data['area']) { echo "checked"; }?>>
							<input type="hidden" name="star" value="0">
							<input type="checkbox" lay-skin="primary" name="star" value="1" title="演员" <?php if($data['star']) { echo "checked"; }?>>
							<input type="hidden" name="director" value="0">
							<input type="checkbox" lay-skin="primary" name="director" value="1" title="导演" <?php if($data['director']) { echo "checked"; }?>>
							<input type="hidden" name="year" value="0">
							<input type="checkbox" lay-skin="primary" name="year" value="1" title="年份" <?php if($data['year']) { echo "checked"; }?>>
							<input type="hidden" name="lang" value="0">
							<input type="checkbox" lay-skin="primary" name="lang" value="1" title="语言" <?php if($data['lang']) { echo "checked"; }?>>
							<input type="hidden" name="letter" value="0">
							<input type="checkbox" lay-skin="primary" name="letter" value="1" title="字母" <?php if($data['letter']) { echo "checked"; }?>>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">播放器按钮</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="reload" value="0">
							<input type="checkbox" lay-skin="primary" name="reload" value="1" title="刷新" <?php if($data['reload']) { echo "checked"; }?>>
							<input type="hidden" name="next" value="0">
							<input type="checkbox" lay-skin="primary" name="next" value="1" title="下一集" <?php if($data['next']) { echo "checked"; }?>>
							<input type="hidden" name="favorite" value="0">
							<input type="checkbox" lay-skin="primary" name="favorite" value="1" title="收藏 " <?php if($data['favorite']) { echo "checked"; }?>>
							<input type="hidden" name="comment" value="0">
							<input type="checkbox" lay-skin="primary" name="comment" value="1" title="评论" <?php if($data['comment']) { echo "checked"; }?>>
							<input type="hidden" name="support" value="0">
							<input type="checkbox" lay-skin="primary" name="support" value="1" title="点赞" <?php if($data['support']) { echo "checked"; }?>>
							<input type="hidden" name="qrcode" value="0">
							<input type="checkbox" lay-skin="primary" name="qrcode" value="1" title="扫码" <?php if($data['qrcode']) { echo "checked"; }?>>
							<input type="hidden" name="copy" value="0">
							<input type="checkbox" lay-skin="primary" name="copy" value="1" title="复制" <?php if($data['copy']) { echo "checked"; }?>>
							<input type="hidden" name="error" value="0">
							<input type="checkbox" lay-skin="primary" name="error" value="1" title="报错" <?php if($data['error']) { echo "checked"; }?>>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">less调试模式</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="less" value="0">
							<input type="checkbox" lay-skin="switch" name="less" value="1"<?php if($data['less']) { echo "checked"; }?>>
						</div>
						<div class="layui-form-mid layui-word-aux">确保您了解的情况下开启，否则可能会导致样式错误，不建议正式环境使用less</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">主题安全</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="modeno" value="0">
							<input type="checkbox" lay-skin="primary" title="禁止调式" name="modeno" value="1"<?php if($data['modeno']) { echo "checked"; }?>>
						</div>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="rightno" value="0">
							<input type="checkbox" lay-skin="primary" title="屏蔽右键" name="rightno" value="1"<?php if($data['rightno']) { echo "checked"; }?>>
						</div>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="f12no" value="0">
							<input type="checkbox" lay-skin="primary" title="禁用F12" name="f12no" value="1"<?php if($data['f12no']) { echo "checked"; }?>>
						</div>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="iframeno" value="0">
							<input type="checkbox" lay-skin="primary" title="禁止框架引用" name="iframeno" value="1"<?php if($data['iframeno']) { echo "checked"; }?>>
						</div>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="selectno" value="0">
							<input type="checkbox" lay-skin="primary" title="禁止选择内容" name="selectno" value="1"<?php if($data['selectno']) { echo "checked"; }?>>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">屏蔽右键</br>提示文字</label>
						<div class="layui-input-inline w420">
							<textarea name="rightnotext" rows="3" class="layui-textarea"><?php echo $data['rightnotext'];?></textarea>
							<div class="layui-form-mid layui-word-aux">留空不启用,例如:你知道的太多啦</div>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">全站变灰</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="text" name="opgreytime" class="layui-input" value="<?php echo $data['opgreytime'];?>" id="laydate" placeholder="选择时间">
							<div class="layui-form-mid layui-word-aux">指定时间，无时间限制可留空</div>
						</div>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="opgrey" value="0">
							<input type="checkbox" lay-skin="primary" name="opgrey" title="启用" value="1"<?php if($data['opgrey']) { echo "checked"; }?>>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">主题版权标识</label>
						<div class="layui-input-inline" style="width: auto;">
							<input type="hidden" name="cody" value="0">
							<input type="checkbox" lay-skin="switch" name="codyright" value="1"<?php if($data['codyright']) { echo "checked"; }?>>
						</div>
						<div class="layui-form-mid layui-word-aux">可关闭，原创正版推荐保留，谢谢！</div>
					</div>
					<div class="layui-form-item">
						<div class="layui-input-block">
							<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
							<button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="?url=more&array=other&type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！">
								<i class="layui-icon layui-icon-delete"></i> 清空设置
							</button>
							<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
						</div>
					</div>
				</form>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

